MIMOS LICENSE GENERATOR - Android source MVP

Status: source project, belum menjadi APK dan belum diuji di perangkat Android.

Build APK:
1. Buka project ini di Android Studio.
2. Pastikan Android SDK Platform 35 terpasang.
3. Sync Gradle, lalu Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug biasanya berada di app/build/outputs/apk/debug/app-debug.apk.

Fitur MVP:
- Nomor akun MT5, nama produk, enam paket harga/durasi.
- Membuat JSON lisensi bertanda tangan RSA-SHA256.
- Menyimpan keypair secara lokal pada SharedPreferences aplikasi.
- Export public key untuk ditanam di EA verifier.

PENTING:
- Ini belum anti-bocor penuh. Private key tersimpan lokal dalam data aplikasi; proteksi tambahan dan backup terenkripsi perlu dibuat sebelum dipakai komersial.
- Lisensi lifetime memakai expiry 2099-12-31 sebagai representasi praktis; bukan tanggal tanpa batas.
- Durasi dihitung sejak waktu generate (UTC), bukan tanggal pembayaran.
- EA MQL5 Build03 belum dimodifikasi dan belum dapat memverifikasi format ini sampai modul verifikasi RSA-SHA256 dibuat dan diuji.
- Jangan distribusikan ke pelanggan sebelum integrasi EA, uji tanda tangan, uji binding akun, uji expiry, dan backup key selesai.
