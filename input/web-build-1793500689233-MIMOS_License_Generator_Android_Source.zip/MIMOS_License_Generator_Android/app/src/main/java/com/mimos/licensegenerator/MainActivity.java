package com.mimos.licensegenerator;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.*;
import org.json.JSONObject;
import java.security.*;
import java.security.spec.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final String PREF="mimos_license_v1";
    private EditText account, product;
    private Spinner plan;
    private TextView output, pubInfo;
    private KeyPair keyPair;
    private final String[] plans={"Trial 7 hari — Rp88.000","Rental 30 hari — Rp288.000","Rental 90 hari — Rp688.000","Rental 180 hari — Rp1.188.888","Rental 1 tahun — Rp1.888.888","Lifetime — Rp8.888.888"};
    private final int[] days={7,30,90,180,365,0};

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(20,18,14)); getWindow().setNavigationBarColor(Color.BLACK); buildUI(); loadOrCreateKeys(); }
    private TextView label(String s){ TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.rgb(230,190,90)); t.setTextSize(14); t.setPadding(0,14,0,6); return t; }
    private void buildUI(){
        ScrollView scroll=new ScrollView(this); LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(24,28,24,30); root.setBackgroundColor(Color.rgb(17,17,17)); scroll.addView(root);
        TextView title=new TextView(this); title.setText("MIMOS"); title.setTextColor(Color.rgb(232,190,83)); title.setTextSize(34); title.setGravity(Gravity.CENTER); title.setTypeface(null,1); root.addView(title);
        TextView sub=new TextView(this); sub.setText("LICENSE GENERATOR  •  OFFLINE"); sub.setTextColor(Color.LTGRAY); sub.setGravity(Gravity.CENTER); sub.setTextSize(12); root.addView(sub);
        root.addView(label("NOMOR AKUN MT5")); account=edit("Contoh: 12345678"); root.addView(account);
        root.addView(label("PRODUK EA")); product=edit("MIMOS_HA_3CANDLE_REVERSAL_Build03"); root.addView(product);
        root.addView(label("PILIH PAKET")); plan=new Spinner(this); ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,plans); plan.setAdapter(a); root.addView(plan);
        Button gen=button("GENERATE LICENSE"); root.addView(gen); gen.setOnClickListener(v->generate());
        output=new TextView(this); output.setTextColor(Color.WHITE); output.setTextSize(13); output.setPadding(12,16,12,16); output.setBackgroundColor(Color.rgb(35,35,35)); root.addView(output);
        Button copy=button("SALIN LICENSE"); root.addView(copy); copy.setOnClickListener(v->{ if(output.getText().length()>0){ ((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("MIMOS License",output.getText())); Toast.makeText(this,"License disalin",Toast.LENGTH_SHORT).show(); }});
        Button export=button("EXPORT PUBLIC KEY"); root.addView(export); export.setOnClickListener(v->exportPublicKey());
        pubInfo=new TextView(this); pubInfo.setTextColor(Color.LTGRAY); pubInfo.setTextSize(11); pubInfo.setPadding(0,14,0,0); root.addView(pubInfo);
        TextView note=new TextView(this); note.setText("PENTING: Ini MVP generator. Simpan backup kunci privat dengan aman. Jangan hapus data aplikasi atau instal ulang sebelum migrasi kunci dirancang. EA harus memakai public key yang diekspor dan verifikasi RSA-SHA256 yang kompatibel. Lisensi offline tidak dapat sepenuhnya mencegah manipulasi jam perangkat."); note.setTextColor(Color.rgb(220,170,80)); note.setTextSize(12); note.setPadding(0,22,0,0); root.addView(note);
        setContentView(scroll);
    }
    private EditText edit(String hint){ EditText e=new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setHintTextColor(Color.GRAY); e.setTextColor(Color.WHITE); e.setPadding(12,10,12,10); e.setBackgroundColor(Color.rgb(40,40,40)); return e; }
    private Button button(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(Color.BLACK); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(218,174,75))); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.topMargin=16; b.setLayoutParams(p); return b; }
    private void loadOrCreateKeys(){
        try { android.content.SharedPreferences p=getSharedPreferences(PREF,0); String priv=p.getString("priv",null), pub=p.getString("pub",null); KeyFactory f=KeyFactory.getInstance("RSA");
            if(priv!=null&&pub!=null){ PrivateKey pr=f.generatePrivate(new PKCS8EncodedKeySpec(Base64.getDecoder().decode(priv))); PublicKey pu=f.generatePublic(new X509EncodedKeySpec(Base64.getDecoder().decode(pub))); keyPair=new KeyPair(pu,pr); }
            else { KeyPairGenerator g=KeyPairGenerator.getInstance("RSA"); g.initialize(3072); keyPair=g.generateKeyPair(); p.edit().putString("priv",Base64.getEncoder().encodeToString(keyPair.getPrivate().getEncoded())).putString("pub",Base64.getEncoder().encodeToString(keyPair.getPublic().getEncoded())).apply(); }
            String fp=hex(MessageDigest.getInstance("SHA-256").digest(keyPair.getPublic().getEncoded())).substring(0,24); pubInfo.setText("Public key fingerprint: "+fp);
        } catch(Exception ex){ Toast.makeText(this,"Gagal menyiapkan kunci: "+ex.getMessage(),Toast.LENGTH_LONG).show(); }
    }
    private void generate(){
        try {
            String acc=account.getText().toString().trim(), prod=product.getText().toString().trim();
            if(!acc.matches("[0-9]{5,15}")){ account.setError("Masukkan nomor akun MT5 5–15 digit"); return; }
            if(prod.isEmpty()){ product.setError("Nama produk wajib diisi"); return; }
            int idx=plan.getSelectedItemPosition(); Calendar c=Calendar.getInstance(TimeZone.getTimeZone("UTC")); String issued=fmt(c.getTime());
            if(days[idx]>0)c.add(Calendar.DAY_OF_YEAR,days[idx]); else c.set(2099,Calendar.DECEMBER,31,23,59,59);
            String expiry=fmt(c.getTime()); String id=UUID.randomUUID().toString();
            JSONObject payload=new JSONObject(); payload.put("issuer","MIMOS UNIVERSE"); payload.put("license_id",id); payload.put("product",prod); payload.put("account",acc); payload.put("plan",plans[idx].split(" — ")[0]); payload.put("issued_utc",issued); payload.put("expiry_utc",expiry); payload.put("lifetime",days[idx]==0); payload.put("version",1);
            byte[] data=payload.toString().getBytes(StandardCharsets.UTF_8); Signature sig=Signature.getInstance("SHA256withRSA"); sig.initSign(keyPair.getPrivate()); sig.update(data); String signature=Base64.getEncoder().encodeToString(sig.sign());
            JSONObject lic=new JSONObject(); lic.put("payload",payload); lic.put("signature",signature); lic.put("algorithm","RSA-SHA256"); output.setText(lic.toString(2));
        }catch(Exception e){ output.setText("ERROR: "+e.getMessage()); }
    }
    private String fmt(Date d){ return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'",Locale.US){{setTimeZone(TimeZone.getTimeZone("UTC"));}}.format(d); }
    private String hex(byte[] b){ StringBuilder s=new StringBuilder(); for(byte x:b)s.append(String.format(Locale.US,"%02x",x)); return s.toString(); }
    private void exportPublicKey(){ try { Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_SUBJECT,"MIMOS Public Key - RSA X.509"); i.putExtra(Intent.EXTRA_TEXT,Base64.getEncoder().encodeToString(keyPair.getPublic().getEncoded())); startActivity(Intent.createChooser(i,"Simpan / kirim public key")); }catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();} }
}
