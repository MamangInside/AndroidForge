# MIMOS License Generator — ECDSA P-256

Android offline license signer compatible with `MIMOS_HA_HOOREE_H1_Build06_ECDSA_P256_PANEL.mq5`.

## Build APK
Push the project to GitHub branch `main`. GitHub Actions builds a debug APK and publishes artifact `mimos-generator-apk`.

## Matching license protocol
- Curve: NIST P-256 / `secp256r1`
- Hash/signature: SHA-256 with ECDSA
- Prefix: `MIMOS1-`
- Payload: exactly 25 bytes
  - byte 0: format version = 1
  - byte 1: product code = 1 (HA HOOREE Build06)
  - byte 2: plan code (2=30 days, 3=90 days, 4=180 days)
  - bytes 3..10: MT5 account login, unsigned 64-bit big-endian
  - bytes 11..14: issue time, unsigned 32-bit Unix seconds, big-endian
  - bytes 15..18: expiry time, unsigned 32-bit Unix seconds, big-endian
  - bytes 19..24: reserved zero bytes
- Signature: fixed 64-byte `r || s` (32 bytes each), Base64URL without padding.
- Complete key: `MIMOS1-` + Base64URL(payload || signature).

The app displays a 144-character Windows CNG `BCRYPT_ECCPUBLIC_BLOB` hex string. Copy it into `MIMOS_PUB_BLOB_HEX` in the EA and compile the EA. The EA must contain the matching public key. The private key stays in the generator.

## Key continuity and security
The app creates one P-256 key pair on first launch and persists it in app-private SharedPreferences. Back up the signing key and keep the backup private. Backup JSON contains the private key in plaintext; never publish or send it to customers. Restoring the same backup preserves compatibility with previously issued licenses. Clearing app data or reinstalling without restoring the backup creates a new key pair; old licenses will not verify against the new public key.

## EA behavior
The supplied EA source adds an on-chart license panel, validates key signatures/account/product/expiry, blocks new entries when invalid or expired, and retains the original position-management code so existing positions continue to be managed. The EA still requires Windows CNG DLL imports (`bcrypt.dll`) to be permitted in MT5.

## Important
The source has not been compiled in MetaEditor in this environment. Compile and test on a demo account before any live deployment. ECDSA verification is only as reliable as the matching public key embedded in the EA and the integrity of the user's terminal/device clock.


## Paket lisensi yang tersedia
- Trial 7 hari (plan code 1)
- Rental 30 hari (plan code 2)
- Rental 90 hari (plan code 3)
- Rental 180 hari (plan code 4)
- Lifetime (plan code 6; expiry sentinel `0xFFFFFFFF`)

Plan code 5 tetap dicadangkan untuk kompatibilitas dengan format lama (rental 1 tahun).
