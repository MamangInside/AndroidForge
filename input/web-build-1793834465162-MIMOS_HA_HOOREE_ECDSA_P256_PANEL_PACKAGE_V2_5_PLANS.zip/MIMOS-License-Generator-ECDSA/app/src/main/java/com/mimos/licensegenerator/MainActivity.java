package com.mimos.licensegenerator;

import android.app.Activity;
import android.os.Bundle;
import android.content.*;
import android.net.Uri;
import android.util.Base64;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.*;
import java.util.Calendar;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

public class MainActivity extends Activity {
    private static final String PREF = "mimos_license_keys";
    private static final String PRIV = "private_pkcs8";
    private static final String PUB = "public_x509";
    private static final int CREATE_BACKUP = 1001, RESTORE_BACKUP = 1002;
    private EditText accountInput;
    private Spinner durationSpinner;
    private TextView output, fingerprint;
    private KeyPair keyPair;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Security.removeProvider("BC");
        Security.addProvider(new BouncyCastleProvider());
        buildUi();
        try {
            keyPair = loadOrCreateKeyPair();
            fingerprint.setText("Key ID: " + keyId(keyPair.getPublic().getEncoded()));
        } catch (Exception e) {
            showError("Gagal menyiapkan signing key: " + e.getMessage());
        }
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(24, 28, 24, 24);
        page.setBackgroundColor(0xFFF7F4EC);

        TextView title = new TextView(this);
        title.setText("MIMOS LICENSE GENERATOR");
        title.setTextSize(22); title.setTextColor(0xFF6B4A00);
        title.setTypeface(null, 1);
        page.addView(title);

        TextView sub = new TextView(this);
        sub.setText("ECDSA P-256 • Offline MIMOS EA license");
        sub.setTextSize(13); sub.setPadding(0, 4, 0, 20);
        page.addView(sub);

        accountInput = new EditText(this);
        accountInput.setSingleLine(true);
        accountInput.setInputType(2);
        accountInput.setHint("Nomor akun MT5");
        page.addView(accountInput);

        durationSpinner = new Spinner(this);
        String[] durations = {"Trial 7 hari", "Rental 30 hari", "Rental 90 hari", "Rental 180 hari", "Lifetime"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_dropdown_item, durations);
        durationSpinner.setAdapter(adapter);
        page.addView(durationSpinner);

        Button generate = button("GENERATE LICENSE");
        generate.setOnClickListener(v -> generateLicense());
        page.addView(generate);

        output = new TextView(this);
        output.setText("License akan muncul di sini.");
        output.setTextIsSelectable(true);
        output.setTextSize(13);
        output.setPadding(12, 16, 12, 16);
        output.setBackgroundColor(0xFFFFFFFF);
        page.addView(output);

        fingerprint = new TextView(this);
        fingerprint.setText("Key ID: menyiapkan...");
        fingerprint.setTextSize(11);
        fingerprint.setPadding(0, 12, 0, 8);
        page.addView(fingerprint);

        Button backup = button("BACKUP SIGNING KEY");
        backup.setOnClickListener(v -> createBackup());
        page.addView(backup);

        Button restore = button("RESTORE SIGNING KEY");
        restore.setOnClickListener(v -> restoreBackup());
        page.addView(restore);

        TextView warning = new TextView(this);
        warning.setText("PENTING: Backup berisi PRIVATE KEY. Simpan di tempat aman dan jangan bagikan. Kehilangan key berarti lisensi lama tidak dapat diverifikasi oleh EA yang memakai public key lama.");
        warning.setTextSize(12); warning.setTextColor(0xFF9B1C1C);
        warning.setPadding(0, 18, 0, 0);
        page.addView(warning);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(page);
        setContentView(scroll);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        return b;
    }

    private KeyPair loadOrCreateKeyPair() throws Exception {
        SharedPreferences p = getSharedPreferences(PREF, MODE_PRIVATE);
        String priv = p.getString(PRIV, null), pub = p.getString(PUB, null);
        KeyFactory kf = KeyFactory.getInstance("EC", "BC");
        if (priv != null && pub != null) {
            PrivateKey privateKey = kf.generatePrivate(new PKCS8EncodedKeySpec(
                Base64.decode(priv, Base64.DEFAULT)));
            PublicKey publicKey = kf.generatePublic(new X509EncodedKeySpec(
                Base64.decode(pub, Base64.DEFAULT)));
            return new KeyPair(publicKey, privateKey);
        }
        KeyPairGenerator gen = KeyPairGenerator.getInstance("EC", "BC");
        gen.initialize(new ECGenParameterSpec("secp256r1"), new SecureRandom());
        KeyPair kp = gen.generateKeyPair();
        saveKeyPair(kp);
        return kp;
    }

    private void saveKeyPair(KeyPair kp) {
        getSharedPreferences(PREF, MODE_PRIVATE).edit()
            .putString(PRIV, Base64.encodeToString(kp.getPrivate().getEncoded(), Base64.NO_WRAP))
            .putString(PUB, Base64.encodeToString(kp.getPublic().getEncoded(), Base64.NO_WRAP))
            .apply();
    }

    private void generateLicense() {
        try {
            if (keyPair == null) throw new Exception("Signing key belum siap.");
            String accountText = accountInput.getText().toString().trim();
            if (!accountText.matches("[0-9]{1,20}")) {
                accountInput.setError("Masukkan nomor akun MT5 yang valid");
                return;
            }
            long account = Long.parseLong(accountText);
            int selectedPlan = durationSpinner.getSelectedItemPosition();
            int[] planCodes = {1, 2, 3, 4, 6}; // 5 is reserved for the legacy 1-year plan
            int[] dayCounts = {7, 30, 90, 180, 0};
            int planCode = planCodes[selectedPlan];
            long issued = System.currentTimeMillis() / 1000L;
            long expiry;
            if (planCode == 6) {
                expiry = 0xFFFFFFFFL; // EA interprets this sentinel as lifetime
            } else {
                expiry = issued + (long) dayCounts[selectedPlan] * 86400L;
            }

            // EA payload: 25 bytes: version, product, plan, account(8), issued(4), expiry(4), reserved(6)
            byte[] payload = new byte[25];
            payload[0] = 1;                 // format version
            payload[1] = 1;                 // product code: HA HOOREE Build06
            payload[2] = (byte) planCode;   // 1=7d, 2=30d, 3=90d, 4=180d, 6=lifetime
            putU64(payload, 3, account);
            putU32(payload, 11, issued);
            putU32(payload, 15, expiry);

            Signature signer = Signature.getInstance("SHA256withECDSA", "BC");
            signer.initSign(keyPair.getPrivate());
            signer.update(payload);
            byte[] der = signer.sign();
            byte[] rawSig = derToRaw(der);
            byte[] combined = new byte[payload.length + rawSig.length];
            System.arraycopy(payload, 0, combined, 0, payload.length);
            System.arraycopy(rawSig, 0, combined, payload.length, rawSig.length);

            String license = "MIMOS1-" + Base64.encodeToString(combined,
                Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
            String pubBlob = publicKeyToCngBlobHex(keyPair.getPublic());
            String planName = selectedPlan == 0 ? "Trial 7 hari" :
                              selectedPlan == 1 ? "Rental 30 hari" :
                              selectedPlan == 2 ? "Rental 90 hari" :
                              selectedPlan == 3 ? "Rental 180 hari" : "Lifetime";
            String expiryText = planCode == 6 ? "Tidak ada tanggal kedaluwarsa (Lifetime)" : new java.util.Date(expiry * 1000L).toString();
            output.setText("LICENSE KEY:\n" + license
                + "\n\nExpiry: " + expiryText
                + "\nPlan: " + planName
                + "\n\nPUBLIC KEY BLOB HEX (paste ke EA):\n" + pubBlob
                + "\n\nKey ID: " + keyId(keyPair.getPublic().getEncoded()));
        } catch (Exception e) { showError("Generate gagal: " + e.getMessage()); }
    }

    private void putU32(byte[] out, int offset, long value) {
        for (int i = 0; i < 4; i++) out[offset + i] = (byte)(value >>> (24 - 8*i));
    }

    private void putU64(byte[] out, int offset, long value) {
        for (int i = 0; i < 8; i++) out[offset + i] = (byte)(value >>> (56 - 8*i));
    }

    private byte[] derToRaw(byte[] der) throws Exception {
        org.bouncycastle.asn1.ASN1Sequence seq =
            org.bouncycastle.asn1.ASN1Sequence.getInstance(der);
        java.math.BigInteger r = org.bouncycastle.asn1.ASN1Integer.getInstance(seq.getObjectAt(0)).getPositiveValue();
        java.math.BigInteger s = org.bouncycastle.asn1.ASN1Integer.getInstance(seq.getObjectAt(1)).getPositiveValue();
        byte[] out = new byte[64];
        copy32(r, out, 0);
        copy32(s, out, 32);
        return out;
    }

    private void copy32(java.math.BigInteger value, byte[] out, int offset) {
        byte[] b = value.toByteArray();
        int src = b.length > 32 ? b.length - 32 : 0;
        int len = Math.min(32, b.length);
        System.arraycopy(b, src, out, offset + 32 - len, len);
    }

    private String publicKeyToCngBlobHex(PublicKey publicKey) throws Exception {
        org.bouncycastle.jce.interfaces.ECPublicKey ec =
            (org.bouncycastle.jce.interfaces.ECPublicKey) publicKey;
        byte[] blob = new byte[72];
        // BCRYPT_ECDSA_PUBLIC_P256_MAGIC = 0x31534345, little-endian
        blob[0] = 0x45; blob[1] = 0x43; blob[2] = 0x53; blob[3] = 0x31;
        blob[4] = 32; blob[5] = 0; blob[6] = 0; blob[7] = 0;
        copy32(ec.getQ().getAffineXCoord().toBigInteger(), blob, 8);
        copy32(ec.getQ().getAffineYCoord().toBigInteger(), blob, 40);
        StringBuilder hex = new StringBuilder();
        for (byte b : blob) hex.append(String.format(java.util.Locale.US, "%02X", b & 0xFF));
        return hex.toString();
    }

    private String keyId(byte[] publicKey) throws Exception {
        byte[] hash = MessageDigest.getInstance("SHA-256").digest(publicKey);
        return Base64.encodeToString(new byte[]{hash[0],hash[1],hash[2],hash[3],hash[4],hash[5]},
            Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
    }

    private void createBackup() {
        if (keyPair == null) { showError("Signing key belum siap."); return; }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, "mimos-signing-key-backup.json");
        startActivityForResult(i, CREATE_BACKUP);
    }

    private void restoreBackup() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("*/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, RESTORE_BACKUP);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == CREATE_BACKUP) {
                String json = "{\n  \"format\": \"MIMOS_ECDSA_KEY_V1\",\n"
                    + "  \"curve\": \"secp256r1\",\n"
                    + "  \"private_pkcs8\": \"" + Base64.encodeToString(keyPair.getPrivate().getEncoded(), Base64.NO_WRAP) + "\",\n"
                    + "  \"public_x509\": \"" + Base64.encodeToString(keyPair.getPublic().getEncoded(), Base64.NO_WRAP) + "\"\n}";
                try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                    os.write(json.getBytes(StandardCharsets.UTF_8));
                }
                Toast.makeText(this, "Backup tersimpan. Amankan file ini!", Toast.LENGTH_LONG).show();
            } else if (requestCode == RESTORE_BACKUP) {
                String json;
                try (InputStream is = getContentResolver().openInputStream(uri);
                     ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
                    byte[] buf = new byte[4096]; int n;
                    while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
                    json = bos.toString("UTF-8");
                }
                String priv = jsonValue(json, "private_pkcs8");
                String pub = jsonValue(json, "public_x509");
                KeyFactory kf = KeyFactory.getInstance("EC", "BC");
                PrivateKey privateKey = kf.generatePrivate(new PKCS8EncodedKeySpec(Base64.decode(priv, Base64.DEFAULT)));
                PublicKey publicKey = kf.generatePublic(new X509EncodedKeySpec(Base64.decode(pub, Base64.DEFAULT)));
                KeyPair restored = new KeyPair(publicKey, privateKey);
                // Verify the pair belongs together before replacing current key.
                byte[] challenge = "MIMOS_KEY_PAIR_CHECK".getBytes(StandardCharsets.UTF_8);
                Signature s = Signature.getInstance("SHA256withECDSA", "BC");
                s.initSign(privateKey); s.update(challenge);
                byte[] signed = s.sign();
                s.initVerify(publicKey); s.update(challenge);
                if (!s.verify(signed)) throw new Exception("Private/public key tidak cocok.");
                saveKeyPair(restored);
                keyPair = restored;
                fingerprint.setText("Key ID: " + keyId(publicKey.getEncoded()));
                Toast.makeText(this, "Signing key berhasil direstore.", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) { showError("Operasi file gagal: " + e.getMessage()); }
    }

    private String jsonValue(String json, String key) throws Exception {
        java.util.regex.Matcher m = java.util.regex.Pattern
            .compile("\"" + key + "\"\\s*:\\s*\"([^\"]+)\"").matcher(json);
        if (!m.find()) throw new Exception("Field " + key + " tidak ditemukan.");
        return m.group(1);
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        if (output != null) output.setText(message);
    }
}
