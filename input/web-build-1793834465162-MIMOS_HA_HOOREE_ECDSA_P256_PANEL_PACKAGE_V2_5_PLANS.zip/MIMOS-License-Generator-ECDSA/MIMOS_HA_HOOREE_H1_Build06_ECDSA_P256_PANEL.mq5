//+------------------------------------------------------------------+
//|                         MIMOS_HA_HOOREE_H1_Build06.mq5           |
//|  H1 HOOREE London Open Filter                                    |
//|  Logic: 5 Candle HA Kuat + London Open 08:00 + Session 08-17     |
//|  Trailing 8/4 + MaxLoss 15                                       |
//|  Lisensi: key pendek MIMOS1-... (ECDSA P-256, Windows CNG)       |
//+------------------------------------------------------------------+
#property copyright "MIMOS UNIVERSE - MIMOS EA LICENSE 01"
#property version   "7.00"
#property strict

#include <Trade/Trade.mqh>
CTrade trade;

//--- Windows CNG (bcrypt.dll): perlu "Allow DLL imports"
#import "bcrypt.dll"
int BCryptOpenAlgorithmProvider(ulong &hAlgorithm, string pszAlgId, string pszImplementation, uint dwFlags);
int BCryptCloseAlgorithmProvider(ulong hAlgorithm, uint dwFlags);
int BCryptImportKeyPair(ulong hAlgorithm, ulong hImportKey, string pszBlobType, ulong &hKey, uchar &pbInput[], uint cbInput, uint dwFlags);
int BCryptDestroyKey(ulong hKey);
int BCryptVerifySignature(ulong hKey, ulong pPaddingInfo, uchar &pbHash[], uint cbHash, uchar &pbSignature[], uint cbSignature, uint dwFlags);
#import

//=== ISI SEKALI: kunci publik dari aplikasi MIMOS License Generator (144 karakter hex) ===
const string MIMOS_PUB_BLOB_HEX = "PASTE_144_KARAKTER_HEX_KUNCI_PUBLIK_DI_SINI";
#define MIMOS_PRODUCT_CODE 1      // 1 = MIMOS_HA_HOOREE_H1_BUILD06
#define MIMOS_KEY_PREFIX   "MIMOS1-"

input string InpLicenseKey = "";                  // Opsional: key awal; bisa juga diisi lewat panel
input string InpLicenseFileName = "MIMOS_LICENSE.txt"; // Cadangan: file berisi key (opsional)

//--- Inputs Strategi Build06 ---
input double InpLot = 0.01;
input ENUM_TIMEFRAMES InpTimeframe = PERIOD_H1;
input int InpConfirmBars = 5;
input bool InpUseStrongFilter = true;
input double InpWickTolPct = 10.0;
input double InpMinBodyPct = 30.0;
input int InpAvgBodyPeriod = 50;
input double InpTrailActivate = 8.0;
input double InpTrailDist = 4.0;
input double InpMaxLoss = 15.0;
input bool InpUseLondonFilter = true;
input int InpLondonOpenHour = 8;
input bool InpUseSessionFilter = true;
input int InpSessionStart = 8;
input int InpSessionEnd = 17;
input long InpMagic = 606060;
input string InpComment = "MIMOS EA LICENSE 01";

int ha_handle = INVALID_HANDLE;
double LondonOpenPrice = 0.0;
datetime LastLondonDate = 0;
datetime last_bar_time = 0;

bool g_license_signature_ok=false;
bool g_license_lifetime=false;
datetime g_license_expiry=0;
string g_plan_name="";
bool g_expiry_notice_sent=false;
bool g_renewal_notice_sent=false;
string UI_PREFIX="MIMOS_LIC_";
string g_panel_key="";

//+------------------------------------------------------------------+
//| Utilitas                                                         |
//+------------------------------------------------------------------+
int HexVal(const ushort c)
{
   if(c>='0' && c<='9') return c-'0';
   if(c>='a' && c<='f') return c-'a'+10;
   if(c>='A' && c<='F') return c-'A'+10;
   return -1;
}

bool HexToBytes(const string hex,uchar &out[])
{
   int n=StringLen(hex);
   if(n==0 || (n%2)!=0) return false;
   ArrayResize(out,n/2);
   for(int i=0;i<n/2;i++)
   {
      int hi=HexVal(StringGetCharacter(hex,i*2));
      int lo=HexVal(StringGetCharacter(hex,i*2+1));
      if(hi<0 || lo<0) return false;
      out[i]=(uchar)(hi*16+lo);
   }
   return true;
}

int B64Val(const ushort c)
{
   if(c>='A' && c<='Z') return c-'A';
   if(c>='a' && c<='z') return c-'a'+26;
   if(c>='0' && c<='9') return c-'0'+52;
   if(c=='-' || c=='+') return 62;
   if(c=='_' || c=='/') return 63;
   return -1;
}

bool B64UrlDecode(const string s,uchar &out[])
{
   ArrayResize(out,0);
   int val=0,bits=0;
   for(int i=0;i<StringLen(s);i++)
   {
      ushort ch=StringGetCharacter(s,i);
      if(ch=='=') break;
      int v=B64Val(ch);
      if(v<0) return false;
      val=(val<<6)|v;
      bits+=6;
      if(bits>=8)
      {
         bits-=8;
         int n=ArraySize(out);
         ArrayResize(out,n+1);
         out[n]=(uchar)((val>>bits)&0xFF);
         val&=((1<<bits)-1);
      }
   }
   return true;
}

string CleanKey(const string raw)
{
   string out="";
   for(int i=0;i<StringLen(raw);i++)
   {
      ushort ch=StringGetCharacter(raw,i);
      if(ch>32 && ch!='"' && ch!='\'') out+=ShortToString(ch);
   }
   return out;
}

string LoadKeyText()
{
   string k=CleanKey(g_panel_key);
   if(k!="") return k;
   k=CleanKey(InpLicenseKey);
   if(k!="") return k;
   int h=FileOpen(InpLicenseFileName,FILE_READ|FILE_TXT|FILE_COMMON|FILE_ANSI);
   if(h==INVALID_HANDLE) h=FileOpen(InpLicenseFileName,FILE_READ|FILE_TXT|FILE_ANSI);
   if(h==INVALID_HANDLE) return "";
   string t="";
   while(!FileIsEnding(h)) t+=FileReadString(h);
   FileClose(h);
   return CleanKey(t);
}

string PlanName(const int code)
{
   switch(code)
   {
      case 1: return "Trial 7 hari";
      case 2: return "Rental 30 hari";
      case 3: return "Rental 90 hari";
      case 4: return "Rental 180 hari";
      case 5: return "Rental 1 tahun";
      case 6: return "Lifetime";
   }
   return "";
}

//+------------------------------------------------------------------+
//| Verifikasi ECDSA P-256 + SHA-256 (signature 64 byte r||s)        |
//+------------------------------------------------------------------+
bool VerifyEcdsa(uchar &payload[],uchar &sig[],string &why)
{
   uchar blob[];
   if(!HexToBytes(MIMOS_PUB_BLOB_HEX,blob) || ArraySize(blob)!=72)
   { why="kunci publik di EA belum diisi / salah (harus 144 karakter hex)"; return false; }

   uchar hash[], nokey[];
   if(CryptEncode(CRYPT_HASH_SHA256,payload,nokey,hash)<=0 || ArraySize(hash)!=32)
   { why="gagal menghitung SHA-256"; return false; }

   ulong hAlg=0,hKey=0;
   if(BCryptOpenAlgorithmProvider(hAlg,"ECDSA_P256",NULL,0)!=0)
   { why="Windows CNG tidak tersedia / DLL imports belum diizinkan"; return false; }

   bool ok=false;
   if(BCryptImportKeyPair(hAlg,0,"ECCPUBLICBLOB",hKey,blob,(uint)ArraySize(blob),0)==0)
      ok=(BCryptVerifySignature(hKey,0,hash,32,sig,64,0)==0);
   else
      why="gagal memuat kunci publik";

   if(hKey!=0) BCryptDestroyKey(hKey);
   if(hAlg!=0) BCryptCloseAlgorithmProvider(hAlg,0);
   if(!ok && why=="") why="tanda tangan key tidak valid";
   return ok;
}

bool ValidateLicense(string &reason)
{
   string key=LoadKeyText();
   if(key=="")
   { reason="Key lisensi belum diisi. Isi kolom InpLicenseKey di tab Inputs."; return false; }
   if(StringFind(key,MIMOS_KEY_PREFIX)!=0)
   { reason="Format key salah (harus diawali "+MIMOS_KEY_PREFIX+")"; return false; }

   uchar raw[];
   if(!B64UrlDecode(StringSubstr(key,StringLen(MIMOS_KEY_PREFIX)),raw) || ArraySize(raw)!=89)
   { reason="Key tidak lengkap / salah salin. Salin ulang seluruh key."; return false; }

   uchar payload[25], sig[64];
   ArrayCopy(payload,raw,0,0,25);
   ArrayCopy(sig,raw,0,25,64);

   string why="";
   if(!VerifyEcdsa(payload,sig,why)) { reason=why; return false; }

   if(payload[0]!=1) { reason="versi key tidak dikenali"; return false; }
   if(payload[1]!=MIMOS_PRODUCT_CODE) { reason="key ini bukan untuk produk EA ini"; return false; }

   ulong lic_account=0;
   for(int i=3;i<=10;i++) lic_account=(lic_account<<8)|payload[i];
   ulong current_account=(ulong)AccountInfoInteger(ACCOUNT_LOGIN);
   if(lic_account==0 || lic_account!=current_account)
   { reason="nomor akun MT5 tidak cocok ("+(string)lic_account+" vs "+(string)current_account+")"; return false; }

   long issued=((long)payload[11]<<24)|((long)payload[12]<<16)|((long)payload[13]<<8)|(long)payload[14];
   long expiry=((long)payload[15]<<24)|((long)payload[16]<<16)|((long)payload[17]<<8)|(long)payload[18];

   if((long)TimeGMT() < issued-86400)
   { reason="jam perangkat tidak sesuai (lebih awal dari tanggal key dibuat)"; return false; }

   g_plan_name=PlanName(payload[2]);
   g_license_lifetime=(expiry==4294967295);
   g_license_expiry=(g_license_lifetime ? (datetime)4102444800 : (datetime)expiry);
   g_license_signature_ok=true;
   reason="OK";
   return true;
}

bool LicenseIsActive()
{
   if(!g_license_signature_ok) return false;
   if(g_license_lifetime) return true;
   return (TimeGMT()<=g_license_expiry);
}


//--- Panel lisensi pada chart
void CreateLicensePanel()
{
   int x=15, y=25;
   ObjectCreate(0,UI_PREFIX+"BG",OBJ_RECTANGLE_LABEL,0,0,0);
   ObjectSetInteger(0,UI_PREFIX+"BG",OBJPROP_CORNER,CORNER_LEFT_UPPER);
   ObjectSetInteger(0,UI_PREFIX+"BG",OBJPROP_XDISTANCE,x);
   ObjectSetInteger(0,UI_PREFIX+"BG",OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,UI_PREFIX+"BG",OBJPROP_XSIZE,330);
   ObjectSetInteger(0,UI_PREFIX+"BG",OBJPROP_YSIZE,138);
   ObjectSetInteger(0,UI_PREFIX+"BG",OBJPROP_BGCOLOR,clrBlack);
   ObjectSetInteger(0,UI_PREFIX+"BG",OBJPROP_BORDER_TYPE,BORDER_FLAT);
   ObjectSetInteger(0,UI_PREFIX+"BG",OBJPROP_COLOR,clrGoldenrod);

   ObjectCreate(0,UI_PREFIX+"TITLE",OBJ_LABEL,0,0,0);
   ObjectSetInteger(0,UI_PREFIX+"TITLE",OBJPROP_CORNER,CORNER_LEFT_UPPER);
   ObjectSetInteger(0,UI_PREFIX+"TITLE",OBJPROP_XDISTANCE,x+10);
   ObjectSetInteger(0,UI_PREFIX+"TITLE",OBJPROP_YDISTANCE,y+8);
   ObjectSetInteger(0,UI_PREFIX+"TITLE",OBJPROP_COLOR,clrGold);
   ObjectSetInteger(0,UI_PREFIX+"TITLE",OBJPROP_FONTSIZE,10);
   ObjectSetString(0,UI_PREFIX+"TITLE",OBJPROP_TEXT,"MIMOS HA HOOREE — LICENSE PANEL");

   ObjectCreate(0,UI_PREFIX+"EDIT",OBJ_EDIT,0,0,0);
   ObjectSetInteger(0,UI_PREFIX+"EDIT",OBJPROP_CORNER,CORNER_LEFT_UPPER);
   ObjectSetInteger(0,UI_PREFIX+"EDIT",OBJPROP_XDISTANCE,x+10);
   ObjectSetInteger(0,UI_PREFIX+"EDIT",OBJPROP_YDISTANCE,y+32);
   ObjectSetInteger(0,UI_PREFIX+"EDIT",OBJPROP_XSIZE,310);
   ObjectSetInteger(0,UI_PREFIX+"EDIT",OBJPROP_YSIZE,24);
   ObjectSetInteger(0,UI_PREFIX+"EDIT",OBJPROP_COLOR,clrWhite);
   ObjectSetInteger(0,UI_PREFIX+"EDIT",OBJPROP_BGCOLOR,clrDimGray);
   ObjectSetString(0,UI_PREFIX+"EDIT",OBJPROP_TEXT,g_panel_key);

   ObjectCreate(0,UI_PREFIX+"BTN",OBJ_BUTTON,0,0,0);
   ObjectSetInteger(0,UI_PREFIX+"BTN",OBJPROP_CORNER,CORNER_LEFT_UPPER);
   ObjectSetInteger(0,UI_PREFIX+"BTN",OBJPROP_XDISTANCE,x+10);
   ObjectSetInteger(0,UI_PREFIX+"BTN",OBJPROP_YDISTANCE,y+63);
   ObjectSetInteger(0,UI_PREFIX+"BTN",OBJPROP_XSIZE,145);
   ObjectSetInteger(0,UI_PREFIX+"BTN",OBJPROP_YSIZE,25);
   ObjectSetString(0,UI_PREFIX+"BTN",OBJPROP_TEXT,"AKTIFKAN LISENSI");

   ObjectCreate(0,UI_PREFIX+"STATUS",OBJ_LABEL,0,0,0);
   ObjectSetInteger(0,UI_PREFIX+"STATUS",OBJPROP_CORNER,CORNER_LEFT_UPPER);
   ObjectSetInteger(0,UI_PREFIX+"STATUS",OBJPROP_XDISTANCE,x+10);
   ObjectSetInteger(0,UI_PREFIX+"STATUS",OBJPROP_YDISTANCE,y+101);
   ObjectSetInteger(0,UI_PREFIX+"STATUS",OBJPROP_COLOR,clrOrange);
   ObjectSetInteger(0,UI_PREFIX+"STATUS",OBJPROP_FONTSIZE,9);
   ObjectSetString(0,UI_PREFIX+"STATUS",OBJPROP_TEXT,"Status: masukkan license key");
   ChartRedraw();
}
void SetLicensePanelStatus(const string msg,const color c)
{
   if(ObjectFind(0,UI_PREFIX+"STATUS")>=0)
   {
      ObjectSetString(0,UI_PREFIX+"STATUS",OBJPROP_TEXT,"Status: "+msg);
      ObjectSetInteger(0,UI_PREFIX+"STATUS",OBJPROP_COLOR,c);
      ChartRedraw();
   }
}
void DeleteLicensePanel()
{
   ObjectDelete(0,UI_PREFIX+"BG"); ObjectDelete(0,UI_PREFIX+"TITLE");
   ObjectDelete(0,UI_PREFIX+"EDIT"); ObjectDelete(0,UI_PREFIX+"BTN");
   ObjectDelete(0,UI_PREFIX+"STATUS");
}
void CheckLicenseExpiryNotice()
{
   if(g_license_signature_ok && !LicenseIsActive() && !g_expiry_notice_sent)
   {
      g_expiry_notice_sent=true;
      Alert("MIMOS HA HOOREE: masa sewa lisensi habis. Posisi berjalan tetap dikelola sampai selesai.");
      SetLicensePanelStatus("EXPIRED — posisi berjalan tetap dikelola",clrTomato);
   }
   if(g_license_signature_ok && !LicenseIsActive() && !PositionSelect(_Symbol) && !g_renewal_notice_sent)
   {
      g_renewal_notice_sent=true;
      Alert("MIMOS HA HOOREE: posisi sudah tidak ada. Silakan perpanjang lisensi.");
      SetLicensePanelStatus("EXPIRED — mohon perpanjang lisensi",clrTomato);
   }
}

//+------------------------------------------------------------------+
int OnInit()
{
   g_panel_key=CleanKey(InpLicenseKey);
   CreateLicensePanel();

   string reason="";
   if(g_panel_key!="")
   {
      if(ValidateLicense(reason))
      {
         if(LicenseIsActive())
         {
            string until=(g_license_lifetime ? "Lifetime" : TimeToString(g_license_expiry,TIME_DATE|TIME_MINUTES)+" UTC");
            SetLicensePanelStatus("AKTIF — "+g_plan_name+" sampai "+until,clrLime);
            Alert("MIMOS LICENSE: key benar. Lisensi aktif.");
         }
         else
         {
            SetLicensePanelStatus("EXPIRED — mohon perpanjang",clrTomato);
            Alert("MIMOS LICENSE: masa sewa sudah habis.");
         }
      }
      else
      {
         SetLicensePanelStatus("KEY SALAH: "+reason,clrTomato);
         Alert("MIMOS LICENSE: key salah/tidak valid. "+reason);
      }
   }
   else SetLicensePanelStatus("masukkan key lalu tekan AKTIFKAN",clrOrange);

   ha_handle = iCustom(_Symbol, InpTimeframe, "Examples\\Heiken_Ashi");
   if(ha_handle == INVALID_HANDLE)
   {
      DeleteLicensePanel();
      return INIT_FAILED;
   }

   trade.SetExpertMagicNumber(InpMagic);
   EventSetTimer(5);
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   DeleteLicensePanel();
   if(ha_handle != INVALID_HANDLE) IndicatorRelease(ha_handle);
}
void OnTimer() { CheckLicenseExpiryNotice(); }
void OnChartEvent(const int id,const long &lparam,const double &dparam,const string &sparam)
{
   if(id==CHARTEVENT_OBJECT_CLICK && sparam==UI_PREFIX+"BTN")
   {
      g_panel_key=CleanKey(ObjectGetString(0,UI_PREFIX+"EDIT",OBJPROP_TEXT));
      g_license_signature_ok=false; g_license_lifetime=false;
      g_license_expiry=0; g_plan_name="";
      g_expiry_notice_sent=false; g_renewal_notice_sent=false;
      string reason="";
      if(ValidateLicense(reason))
      {
         if(LicenseIsActive())
         {
            string until=(g_license_lifetime ? "Lifetime" : TimeToString(g_license_expiry,TIME_DATE|TIME_MINUTES)+" UTC");
            SetLicensePanelStatus("AKTIF — "+g_plan_name+" sampai "+until,clrLime);
            Alert("MIMOS LICENSE: key benar. Lisensi aktif sampai "+until);
         }
         else
         {
            SetLicensePanelStatus("EXPIRED — mohon perpanjang",clrTomato);
            Alert("MIMOS LICENSE: key benar tetapi masa sewanya habis.");
         }
      }
      else
      {
         SetLicensePanelStatus("KEY SALAH: "+reason,clrTomato);
         Alert("MIMOS LICENSE: key salah/tidak valid. "+reason);
      }
   }
}

bool IsNewBar()
{
   datetime t[];
   ArraySetAsSeries(t, true);
   if(CopyTime(_Symbol, InpTimeframe, 0, 1, t) <= 0) return false;
   if(t[0] == last_bar_time) return false;
   last_bar_time = t[0];
   return true;
}

double GetAvgBody(int period)
{
   if(period <= 0) return 0.0;
   double o[], c[];
   ArraySetAsSeries(o, true); ArraySetAsSeries(c, true);
   if(CopyBuffer(ha_handle, 0, 0, period + 10, o) <= 0) return 0.0;
   if(CopyBuffer(ha_handle, 3, 0, period + 10, c) <= 0) return 0.0;
   double sum = 0.0; int cnt = 0;
   for(int i = 1; i <= period; i++) { sum += MathAbs(c[i] - o[i]); cnt++; }
   return (cnt > 0 ? sum / cnt : 0.0);
}

bool IsValidGreen(int shift, double avg_body)
{
   double o[], c[], l[];
   ArraySetAsSeries(o, true); ArraySetAsSeries(c, true); ArraySetAsSeries(l, true);
   if(CopyBuffer(ha_handle, 0, shift, 1, o) <= 0) return false;
   if(CopyBuffer(ha_handle, 3, shift, 1, c) <= 0) return false;
   if(CopyBuffer(ha_handle, 2, shift, 1, l) <= 0) return false;
   if(c[0] <= o[0]) return false;
   double body = c[0] - o[0];
   if(InpMinBodyPct > 0 && avg_body > 0 && body < (InpMinBodyPct / 100.0) * avg_body) return false;
   double lw = MathMin(o[0], c[0]) - l[0];
   if(InpUseStrongFilter && lw > (InpWickTolPct / 100.0) * MathMax(body, 0.01)) return false;
   return true;
}

bool IsValidRed(int shift, double avg_body)
{
   double o[], c[], h[];
   ArraySetAsSeries(o, true); ArraySetAsSeries(c, true); ArraySetAsSeries(h, true);
   if(CopyBuffer(ha_handle, 0, shift, 1, o) <= 0) return false;
   if(CopyBuffer(ha_handle, 3, shift, 1, c) <= 0) return false;
   if(CopyBuffer(ha_handle, 1, shift, 1, h) <= 0) return false;
   if(c[0] >= o[0]) return false;
   double body = o[0] - c[0];
   if(InpMinBodyPct > 0 && avg_body > 0 && body < (InpMinBodyPct / 100.0) * avg_body) return false;
   double uw = h[0] - MathMax(o[0], c[0]);
   if(InpUseStrongFilter && uw > (InpWickTolPct / 100.0) * MathMax(body, 0.01)) return false;
   return true;
}

bool UpdateLondonOpen()
{
   MqlDateTime dt;
   TimeToStruct(TimeCurrent(), dt);
   if(dt.hour == InpLondonOpenHour)
   {
      datetime today = (datetime)StructToTime(dt) - dt.hour * 3600 - dt.min * 60 - dt.sec;
      if(today != LastLondonDate)
      {
         double op[];
         ArraySetAsSeries(op, true);
         if(CopyOpen(_Symbol, InpTimeframe, 0, 1, op) > 0)
         {
            LondonOpenPrice = op[0];
            LastLondonDate = today;
         }
      }
   }
   return true;
}

void OnTick()
{
   CheckLicenseExpiryNotice();
   if(!IsNewBar()) return;
   UpdateLondonOpen();
   MqlDateTime dt;
   TimeToStruct(TimeCurrent(), dt);

   if(PositionSelect(_Symbol))
   {
      long pt = PositionGetInteger(POSITION_TYPE);
      double op = PositionGetDouble(POSITION_PRICE_OPEN);
      double sl = PositionGetDouble(POSITION_SL);
      double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
      double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
      bool close_position = false;

      if(pt == POSITION_TYPE_BUY)
      {
         double f = bid - op;
         if(f >= InpTrailActivate)
         {
            double ns = bid - InpTrailDist;
            if(ns > sl || sl == 0.0) trade.PositionModify(_Symbol, ns, PositionGetDouble(POSITION_TP));
         }
         if(f <= -InpMaxLoss) close_position = true;
      }
      else if(pt == POSITION_TYPE_SELL)
      {
         double f = op - ask;
         if(f >= InpTrailActivate)
         {
            double ns = ask + InpTrailDist;
            if(ns < sl || sl == 0.0) trade.PositionModify(_Symbol, ns, PositionGetDouble(POSITION_TP));
         }
         if(f <= -InpMaxLoss) close_position = true;
      }

      if(close_position) { trade.PositionClose(_Symbol); return; }
   }

   double avg = GetAvgBody(InpAvgBodyPeriod);
   bool nG = true, nR = true;
   for(int s = 1; s <= InpConfirmBars; s++)
   {
      if(!IsValidGreen(s, avg)) nG = false;
      if(!IsValidRed(s, avg)) nR = false;
      if(!nG && !nR) break;
   }

   bool allowB = true, allowS = true;
   if(InpUseLondonFilter && LondonOpenPrice > 0.0)
   {
      double cc[];
      ArraySetAsSeries(cc, true);
      if(CopyClose(_Symbol, InpTimeframe, 0, 1, cc) > 0)
      {
         if(cc[0] > LondonOpenPrice) allowS = false;
         else if(cc[0] < LondonOpenPrice) allowB = false;
      }
   }

   if(!LicenseIsActive()) return;

   if(InpUseSessionFilter)
   {
      if(dt.hour < InpSessionStart || dt.hour > InpSessionEnd) return;
   }

   if(!PositionSelect(_Symbol))
   {
      if(nG && allowB)
      {
         double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
         trade.Buy(InpLot, _Symbol, ask, 0.0, 0.0, InpComment);
      }
      else if(nR && allowS)
      {
         double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
         trade.Sell(InpLot, _Symbol, bid, 0.0, 0.0, InpComment);
      }
   }
}
