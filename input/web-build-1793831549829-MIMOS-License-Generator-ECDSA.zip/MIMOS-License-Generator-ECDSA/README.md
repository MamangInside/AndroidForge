# MIMOS License Generator — ECDSA

Android offline license signer for MIMOS MT5 products.

## Build
Push this project to GitHub branch `main`. GitHub Actions builds a debug APK and publishes it as artifact `mimos-generator-apk`.

## License format
`M1.<account>.<expiry_epoch>.<signature_base64url>`

Signed canonical payload (UTF-8):
`MIMOS1|<account>|<expiry_epoch>`

Algorithm: ECDSA secp256k1 with SHA-256 (`SHA256withECDSA`). Signature is standard ASN.1 DER encoded, then Base64 URL-safe without padding.

## Important integration note
The EA must verify the signature using the matching public key. The EA must reconstruct the exact canonical payload, decode Base64URL signature, convert Base64URL to standard Base64 if needed, and perform ECDSA verification on secp256k1. Account binding and expiry are not secure unless signature verification succeeds.

This ZIP does **not** include the MQL5 ECDSA verifier. Do not treat substring/account checks as license authentication. A production EA must reject malformed signatures, wrong accounts, expired timestamps, and unknown format versions.

## Key handling
The app creates one key pair on first launch and persists its encoded keys in app-private SharedPreferences. Backup exports the private key in plaintext JSON. Store that backup securely and never publish it. Restoring the same backup preserves the public key and keeps previously issued licenses verifiable.

If app data is cleared or the app is reinstalled without restoring the backup, a new key pair is generated and old licenses will no longer verify. The public key embedded in the EA must match the generator key.
